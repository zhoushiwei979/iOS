//
//  SevenPrinciplesViewController.swift
//  iosTest
//
//  Created by 周诗玮 on 2024/10/23.
//

import UIKit

/// 七大原则
class SevenPrinciplesViewController: UIViewController {

    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // MARK: - 1 总原则：开闭原则(Open/Closed Principle，OCP)
        
        // 创建一辆汽车
        let car = Car()
        car.brand = "Ford"
        car.price = 100000

        // 使用装饰器来添加自动驾驶功能
        let decorator = AutoDriveDecorator(car: car)
        decorator.startEngine()
        
        
        // MARK: - 2 单一职责原则(Single responsibility principle, SRP)
        let employee = Employee()
        employee.name = "Layton Pike"
        employee.age = 20
        employee.department = "iOS development department"
        let salaryCalculator = SalaryCalculator()
        salaryCalculator.calculateSalary(for: employee)
        let taskPerformer = TaskPerformer()
        taskPerformer.performDailyTasks(for: employee)
        
        
        // MARK: - 3 里氏替换原则(Liskov Substitution Principle, LSP)
        let animal = Dog()
        animal.run()
        
        
        // MARK: - 4 依赖倒转原则(Dependency Inversion Principle)
        let logClass = MyClass()
        let logger = Logger()
        logClass.logger = logger
        logClass.log()
        
        
        // MARK: - 5 接口隔离原则(Interface Segregation Principle)
        let database = Database()
        let userService = UserService(database: database)
        database.connect()
        userService.saveUser("ios", withEmail: "ios.com")
        database.disConnect()
        
        
        // MARK: - 6 迪米特法则（最少知道原则）(The Law of Demeter, LoD)
        let user = User()
        user.name = "ios"
        // apple
        let apple = Goods()
        apple.name = "apple"
        apple.price = 5.0
        // orange
        let orange = Goods()
        orange.name = "orange"
        orange.price = 5.0
        // 用户添加商品到购物车
        user.addGoods(toCart: apple)
        user.addGoods(toCart: orange)
        // 结账
        user.checkOut()
        
        
        // MARK: - 7 合成复用原则(Composite Reuse Principle, CRP)
        // 一个类作为另一个类的成员变量，通过调用该成员变量的方法来实现该类的功能
    }
}

// MARK: - 1 总原则：开闭原则(Open/Closed Principle，OCP)
// 原有代码：汽车类
class Car: NSObject {
    var brand: String?
    var price = 0

    func startEngine() {
        print("Start Engine!")
    }
}

// 新需求：添加自动驾驶功能
// 抽象类：汽车装饰器
class CarDecorator: Car {
    var car: Car?

    init(car: Car?) {
        super.init()
        self.car = car
    }

    override func startEngine() {
        car?.startEngine()
    }
}

// 具体装饰器：自动驾驶装饰器
class AutoDriveDecorator: CarDecorator {
    func startAutoDriving() {
        print("Auto Driving!")
    }

    override func startEngine() {
        super.startEngine()
        startAutoDriving()
    }
}


// MARK: - 2 单一职责原则(Single responsibility principle, SRP)
// 遵循单一职责原则的代码示例
class Employee: NSObject {
    var name: String?
    var age = 0
    var department: String?
    // Employee 类的代码只包含员工的基本信息，不再包含计算薪水和执行日常任务的代码
}

class SalaryCalculator: NSObject {
    func calculateSalary(for employee: Employee?) {
        // 计算员工薪水的代码
        if let name = employee?.name, let age = employee?.age, let department = employee?.department {
            print(String(format: "calculateSalaryForEmployee: name: %@, age: %ld, department: %@", name, age, department))
        }
    }
}

class TaskPerformer: NSObject {
    func performDailyTasks(for employee: Employee?) {
        // 执行员工日常任务的代码
        if let name = employee?.name, let age = employee?.age, let department = employee?.department {
            print(String(format: "performDailyTasksForEmployee: name: %@, age: %ld, department: %@", name, age, department))
        }
    }
}


// MARK: - 3 里氏替换原则(Liskov Substitution Principle, LSP)
class Animal: NSObject {
    func run() {
        print("Animal is running")
    }
}

class Dog: Animal {
    override func run() {
        print("Dog is running")
    }
}


// MARK: - 4 依赖倒转原则(Dependency Inversion Principle)
protocol LoggerProtocol: NSObjectProtocol {
    func log(_ message: String?)
}

class Logger: NSObject, LoggerProtocol {
    func log(_ message: String?) {
        print("\(message ?? "")")
    }
}

class MyClass: NSObject {
    var logger: Logger?

    func log() {
    }

    func doSomething() {
        logger?.log("Log something")
    }
}


// MARK: - 5 接口隔离原则(Interface Segregation Principle)
protocol DatabaseProtocol: NSObjectProtocol {
    func executeSQL(_ sql: String?)
}

class Database: NSObject, DatabaseProtocol {
    func disconnect() {
    }

    // MARK: - Method

    func connect() {
        print("Connect to database")
    }

    func disConnect() {
        print("Disconnect from database")
    }

    // MARK: - DatabaseProtocol

    func executeSQL(_ sql: String?) {
        print("Execute SQL: \(sql ?? "")")
    }
}

class UserService: NSObject {
    var database: (any DatabaseProtocol)?
    
    init(database: (any DatabaseProtocol)?) {
        super.init()
        self.database = database
    }
    
    func saveUser(_ name: String?, withEmail email: String?) {
        database?.executeSQL("INSERT INTO users(name, email) VALUES('\(name ?? "")', '\(email ?? "")')")
    }
}


// MARK: - 6 迪米特法则（最少知道原则）(The Law of Demeter, LoD)
// 商品类
class Goods: NSObject {
    var name: String = ""
    var price: CGFloat = 0.0
}

// 购物车类
class ShoppingCart: NSObject {
    
    var goodsArray: [Goods]
    
    override init() {
        goodsArray = []
    }
    
    func addGoodsInfo(_ goods: Goods?) {
        if let goods {
            goodsArray.append(goods)
        }
        if let name = goods?.name {
            print("添加商品 \(name) 到购物车")
        }
    }
    
    func printShoppingList() {
        print("========== 购物车清单 ==========")
        for info in goodsArray {
            print("\(info.name) , \(info.price)")
        }
        print("================================")
    }
}

class User: NSObject {
    var name: String?
    var shoppingCart: ShoppingCart?
    
    override init() {
        super.init()
        shoppingCart = ShoppingCart()
    }
    
    func addGoods(toCart goods: Goods?) {
        shoppingCart?.addGoodsInfo(goods)
    }
    
    func checkOut() {
        print("用户 \(name ?? "") 结账，购物清单如下：")
        shoppingCart?.printShoppingList()
    }
}

// MARK: - 7 合成复用原则(Composite Reuse Principle, CRP)
// 一个类作为另一个类的成员变量，通过调用该成员变量的方法来实现该类的功能
