//
//  BehaviorPatternViewController.swift
//  Design pattern
//
//  Created by 周诗玮 on 2024/10/25.
//

import UIKit

/// 行为型模式
class BehaviorPatternViewController: UIViewController {
    
    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: - 1 责任链模式(Chain of Responsibility Pattern)
        // 创建处理者对象
        let handlerA = ConcreteHandlerA()
        let handlerB = ConcreteHandlerB()
        let handlerC = ConcreteHandlerC()
        // 设置处理者之间的关系
        handlerA.nextHandler = handlerB
        handlerB.nextHandler = handlerC
        // 发送请求
        handlerA.handleRequest(5)
        handlerA.handleRequest(15)
        handlerC.handleRequest(25)
        
        
        // MARK: - 2 观察者模式(Observer Pattern)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(loginCompletedNotificationReceived),
            name: NSNotification.Name("LoginCompletedNotification"),
            object: nil)
       
        
        // MARK: - 3 策略模式(Strategy Pattern)
        let calculator = Calculator()

        // 用户选择加法运算
        calculator.strategy = AdditionStrategy()
        var result = calculator.performOperation(withNumber: 5, andNumber: 3)
        print(String(format: "加法结果：%ld", result))

        // 用户选择减法运算
        calculator.strategy = SubtractionStrategy()
        result = calculator.performOperation(withNumber: 5, andNumber: 3)
        print(String(format: "减法结果：%ld", result))
        
        // 用户选择乘法运算
        calculator.strategy = MultiplicationStrategy()
        result = calculator.performOperation(withNumber: 5, andNumber: 3)
        print(String(format: "乘法结果：%ld", result))
        
        
        // MARK: - 4 模板方法模式(Template Method Pattern)
        let class1 = ConcreteClass1()
        class1.templateMethod()
        // Output:
        // ConcreteClass1: 执行步骤 1
        // ConcreteClass1: 执行步骤 2
        let class2 = ConcreteClass2()
        class2.templateMethod()
        // Output:
        // ConcreteClass2: 执行步骤 1
        // ConcreteClass2: 执行步骤 2
        
        
        // MARK: - 5 命令模式(Command Pattern)
        // 创建接收者对象
        let receiver = Receiver()
        // 创建具体命令对象并将接收者传递给它
        let command = ConcreteCommand(receiver: receiver)
        // 创建发送者对象，并设置命令
        let invoker = Invoker()
        invoker.command = command
        // 发送者触发命令执行
        invoker.executeCommand()
        
        
        // MARK: - 6 解释器模式(Interpreter Pattern)
        let context = Context()
        context.variables = [
            "x": 10,
            "y": 5
        ]
        let expression = AdditionExpression()
        expression.leftExpression = NumberExpression()
        (expression.leftExpression as? NumberExpression)?.number = context.value(forVariable: "x") ?? 0
        expression.rightExpression = SubtractionExpression()
        (expression.rightExpression as? SubtractionExpression)?.leftExpression = NumberExpression()
        ((expression.rightExpression as? SubtractionExpression)?.leftExpression as? NumberExpression)?.number = context.value(
            forVariable: "y") ?? 0
        (expression.rightExpression as? SubtractionExpression)?.rightExpression = NumberExpression()
        ((expression.rightExpression as? SubtractionExpression)?.rightExpression as? NumberExpression)?.number = 2
        let interpreterResult = expression.interpret(withContext: context.variables)
        print(String(format: "Result: %ld", interpreterResult))
        
        
        // MARK: - 7 迭代器模式(Iterator Pattern)
        let array = ["Item 1", "Item 2", "Item 3", "Item 4"]
        // 创建具体集合对象
        let aggregate = ConcreteAggregate(collection: array)
        // 创建迭代器对象
        let iterator = aggregate.createIterator()
        // 使用迭代器遍历集合对象
        while iterator?.hasNext() == true {
            let item = iterator?.next()
            if let item {
                print("\(item)")
            }
        }
        
        
        // MARK: - 8 中介者模式(Mediator Pattern)
        // 中介者
        let mediator = ConcreteMediator()
        // 两个通信的同事
        let colleague1 = ConcreteColleague1(mediator: mediator)
        let colleague2 = ConcreteColleague2(mediator: mediator)
        mediator.colleague1 = colleague1
        mediator.colleague2 = colleague2
        // 通信
        colleague1.send("Hello, colleague2!")
        colleague2.send("Hello, colleague1!")
        
        
        // MARK: - 9 备忘录模式(Memento Pattern)
        // 使用备忘录模式
        let originator = Originator()
        let caretaker = Caretaker()
        // 设置发起人的状态
        originator.state = "state1"
        // 创建备忘录并保存状态
        let memento1 = originator.createMemento()
        caretaker.add(memento1)
        // 修改发起人的状态
        originator.state = "state2"
        // 创建备忘录并保存状态
        let memento2 = originator.createMemento()
        caretaker.add(memento2)
        // 恢复到第一个备忘录保存的状态
        let saveMemento = caretaker.getMementoAt(0)
        originator.restore(from: saveMemento)
        print("Current state: \(originator.state ?? "")")
        
        
        // MARK: - 10 状态模式(State Pattern)
        let player = MusicPlayer()
        player.playMusic() // output：开始播放音乐
        player.pauseMusic() // output：暂停音乐
        player.playMusic() // output：继续播放音乐
        player.stopMusic() // output：停止播放音乐
        
        
        // MARK: - 11 访问者模式(Visitor Pattern)
        let elementA = ConcreteElementA()
        let elementB = ConcreteElementB()
        let visitor = ConcreteVisitor()
        // 通过将访问者对象传递给元素，元素可以将自身委托给访问者来执行特定的操作
        elementA.acceptVisitor(visitor)
        elementB.acceptVisitor(visitor)
        
        
    }
    
    // MARK: - 2 观察者模式(Observer Pattern)
    ///
    
    deinit {
        // 在视图控制器销毁时，要取消观察
        NotificationCenter.default.removeObserver(self)
    }

    @objc func loginCompletedNotificationReceived() {
        // 收到登录完成通知后的操作
        // ...
        print("登录成功")
    }
    
}


// MARK: - 1 责任链模式(Chain of Responsibility Pattern)
///
// 抽象处理者
class Handler: NSObject {
    var nextHandler: Handler?

    func handleRequest(_ request: Int) {
        if let nextHandler {
            nextHandler.handleRequest(request)
        }
    }
}

// 具体处理者A
class ConcreteHandlerA: Handler {
    override func handleRequest(_ request: Int) {
        if request < 10 {
            print(String(format: "ConcreteHandlerA 处理了请求 %ld", request))
        } else if (nextHandler != nil) {
            nextHandler?.handleRequest(request)
        }
    }
}

// 具体处理者B
class ConcreteHandlerB: Handler {
    override func handleRequest(_ request: Int) {
        if request >= 10 && request < 20 {
            print(String(format: "ConcreteHandlerB 处理了请求 %ld", request))
        } else if (nextHandler != nil) {
            nextHandler?.handleRequest(request)
        }
    }
}

// 具体处理者C
class ConcreteHandlerC: Handler {
    override func handleRequest(_ request: Int) {
        if request >= 20 {
            print(String(format: "ConcreteHandlerC 处理了请求 %ld", request))
        } else if (nextHandler != nil) {
            nextHandler?.handleRequest(request)
        }
    }
}


// MARK: - 2 观察者模式(Observer Pattern)
///
func loginButtonTapped() {
    // 执行登录操作
    // ...

    // 发送登录完成的通知
    NotificationCenter.default.post(name: NSNotification.Name("LoginCompletedNotification"), object: nil)
}


// MARK: - 3 策略模式(Strategy Pattern)
// 策略接口
protocol Strategy: NSObjectProtocol {
    func executeOperation(withNumber number1: Int, andNumber number2: Int) -> Int
}

// 具体策略类：加法策略
class AdditionStrategy: NSObject, Strategy {
    func executeOperation(withNumber number1: Int, andNumber number2: Int) -> Int {
        return number1 + number2
    }
}

// 具体策略类：减法策略
class SubtractionStrategy: NSObject, Strategy {
    func executeOperation(withNumber number1: Int, andNumber number2: Int) -> Int {
        return number1 - number2
    }
}

// 具体策略类：乘法策略
class MultiplicationStrategy: NSObject, Strategy {
    func executeOperation(withNumber number1: Int, andNumber number2: Int) -> Int {
        return number1 * number2
    }
}

// 上下文类：计算器
class Calculator: NSObject {
    var strategy: Strategy?

    func performOperation(withNumber number1: Int, andNumber number2: Int) -> Int {
        return strategy?.executeOperation(withNumber: number1, andNumber: number2) ?? 0
    }
}


// MARK: - 4 模板方法模式(Template Method Pattern)
// 基类
class AbstractClass: NSObject {
 // 模板方法
    func templateMethod() {
        // 执行算法的骨架
        primitiveOperation1()
        primitiveOperation2()
    }

    // 需要子类实现的抽象方法
    func primitiveOperation1() {
        // 默认实现或者空实现，子类可以选择性地重写
    }

    func primitiveOperation2() {
        // 默认实现或者空实现，子类可以选择性地重写
    }
}

// 子类 1
class ConcreteClass1: AbstractClass {
    override func primitiveOperation1() {
        print("ConcreteClass1: 执行步骤 1")
    }
    override func primitiveOperation2() {
        print("ConcreteClass1: 执行步骤 2")
    }
}

// 子类 2
class ConcreteClass2: AbstractClass {
    override func primitiveOperation1() {
        print("ConcreteClass2: 执行步骤 1")
    }
    override func primitiveOperation2() {
        print("ConcreteClass2: 执行步骤 2")
    }
}


// MARK: - 5 命令模式(Command Pattern)
//
protocol Command: NSObjectProtocol {
    func execute()
}

//
class Receiver: NSObject {
    func performAction() {
        print("Receiver: Performing action.")
    }
}

//
class ConcreteCommand: NSObject, Command {
    var receiver: Receiver?

    init(receiver: Receiver?) {
        super.init()
        self.receiver = receiver
    }

    func execute() {
        receiver?.performAction()
    }
}

//
class Invoker: NSObject {
    
    var command: Command?

    func executeCommand() {
        command?.execute()
    }
}


// MARK: - 6 解释器模式(Interpreter Pattern)
// 抽象表达式
protocol Expression: NSObjectProtocol {
    func interpret(withContext context: [String : Int]?) -> Int
}

// 终结符表达式
class NumberExpression: NSObject, Expression {
    var number = 0

    func interpret(withContext context: [String : Int]?) -> Int {
        return number
    }
}

// 非终结符表达式 - 加法
class AdditionExpression: NSObject, Expression {
    var leftExpression: Expression?
    var rightExpression: Expression?
    
    func interpret(withContext context: [String : Int]?) -> Int {
        let leftValue = leftExpression?.interpret(withContext: context) ?? 0
        let rightValue = rightExpression?.interpret(withContext: context) ?? 0
        return leftValue + rightValue
    }
}

// 非终结符表达式 - 减法
class SubtractionExpression: NSObject, Expression {
    var leftExpression: Expression?
    var rightExpression: Expression?
    
    func interpret(withContext context: [String : Int]?) -> Int {
        let leftValue = leftExpression?.interpret(withContext: context) ?? 0
        let rightValue = rightExpression?.interpret(withContext: context) ?? 0
        return leftValue - rightValue
    }
}

// 上下文
class Context: NSObject {
    var variables: [String : Int]?

    func value(forVariable variableName: String?) -> Int? {
        return variables?[variableName ?? ""]
    }
}


// MARK: - 7 迭代器模式(Iterator Pattern)
// 迭代器接口
protocol Iterator: NSObjectProtocol {
    func hasNext() -> Bool
    func next() -> String?
}

// 集合接口
protocol Aggregate: NSObjectProtocol {
    func createIterator() -> Iterator?
}

// 具体迭代器类
class ConcreteIterator: NSObject, Iterator {
    var collection: [String]?
    var currentIndex = 0
    
    init(collection: [String]?) {
        super.init()
        self.collection = collection
        currentIndex = 0
    }
    
    func hasNext() -> Bool {
        return currentIndex < collection?.count ?? 0
    }
    
    func next() -> String? {
        if !hasNext() {
            return nil
        }
        let item = collection?[currentIndex]
        currentIndex += 1
        return item
    }
}

// 具体集合类
class ConcreteAggregate: NSObject, Aggregate {
    var collection: [String]?

    init(collection: [String]?) {
        super.init()
        self.collection = collection
    }

    func createIterator() -> Iterator? {
        return ConcreteIterator(collection: collection)
    }
}


// MARK: - 8 中介者模式(Mediator Pattern)
// 中介者接口
protocol Mediator: NSObjectProtocol {
    func sendMessage(_ message: String?, fromColleague colleague: Colleague?)
}

// 具体中介者
class ConcreteMediator: NSObject, Mediator {
    
    var colleague1: Colleague?
    var colleague2: Colleague?
    
    func sendMessage(_ message: String?, fromColleague colleague: Colleague?) {
        if colleague == colleague1 {
            // colleague1发送消息时，通知colleague2
            colleague2?.receiveMessage(message)
        } else if colleague == colleague2 {
            // colleague2发送消息时，通知colleague1
            colleague1?.receiveMessage(message)
        }
    }
}

// 抽象同事类
class Colleague: NSObject {
    weak var mediator: Mediator?

    init(mediator: Mediator?) {
        super.init()
        self.mediator = mediator
    }

    func send(_ message: String?) {
        mediator?.sendMessage(message, fromColleague: self)
    }
    
    func receiveMessage(_ message: String?) {
        print("Received message: \(message ?? "")")
    }
}

// 具体同事类
class ConcreteColleague1: Colleague {
}

class ConcreteColleague2: Colleague {
}


// MARK: - 9 备忘录模式(Memento Pattern)
// 备忘录对象
class Memento: NSObject {
    var state: String?
}

// 发起人对象
class Originator: NSObject {
    var state: String?

    func createMemento() -> Memento? {
        let memento = Memento()
        memento.state = state
        return memento
    }

    func restore(from memento: Memento?) {
        state = memento?.state
    }
}

// 管理者对象
class Caretaker: NSObject {
    var mementos: [Memento]?

    override init() {
        super.init()
        mementos = []
    }

    func add(_ memento: Memento?) {
        if let memento {
            mementos?.append(memento)
        }
    }
    
    func getMementoAt(_ index: Int) -> Memento? {
        if index < (mementos?.count ?? 0) {
            return mementos?[index]
        }
        return nil
    }
}


// MARK: - 10 状态模式(State Pattern)
// 状态接口
protocol State: NSObjectProtocol {
    func play()
    func pause()
    func stop()
}

// 具体状态类：播放状态
class PlayState: NSObject, State {
    func play() {
        print("当前已经在播放音乐")
    }

    func pause() {
        print("暂停音乐")
    }

    func stop() {
        print("停止播放音乐")
    }
}

// 具体状态类：暂停状态
class PauseState: NSObject, State {
    func play() {
        print("继续播放音乐")
    }

    func pause() {
        print("音乐已经暂停")
    }

    func stop() {
        print("停止播放音乐")
    }
}

// 具体状态类：停止状态
class StopState: NSObject, State {
    func play() {
        print("开始播放音乐")
    }

    func pause() {
        print("音乐已经停止")
    }

    func stop() {
        print("音乐已经停止")
    }
}

// 上下文类
class MusicPlayer: NSObject {
    var currentState: State?
    
    override init() {
        super.init()
        // 初始状态为停止状态
        currentState = StopState()
    }
    
    func playMusic() {
        currentState?.play()
        currentState = PlayState()
    }
    
    func pauseMusic() {
        currentState?.pause()
        currentState = PauseState()
    }
    
    func stopMusic() {
        currentState?.stop()
        currentState = StopState()
    }
}


// MARK: - 11 访问者模式(Visitor Pattern)
///
protocol Element: NSObjectProtocol {
    func acceptVisitor(_ visitor: Visitor?)
}

protocol Visitor: NSObjectProtocol {
    func visit(elementA: ConcreteElementA?)
    func visit(elementB: ConcreteElementB?)
}

class ConcreteElementA: NSObject, Element {
    func acceptVisitor(_ visitor: Visitor?) {
        visitor?.visit(elementA: self)
    }

    func operationA() -> String? {
        return "ConcreteElementA operation"
    }
}

class ConcreteElementB: NSObject, Element {
    func acceptVisitor(_ visitor: Visitor?) {
        visitor?.visit(elementB: self)
    }

    func operationB() -> String? {
        return "ConcreteElementB operation"
    }
}

class ConcreteVisitor: NSObject, Visitor {
    func visit(elementA: ConcreteElementA?) {
        let result = elementA?.operationA()
        print("Visitor is operating on ElementA: \(result ?? "")")
    }

    func visit(elementB: ConcreteElementB?) {
        let result = elementB?.operationB()
        print("Visitor is operating on ElementB: \(result ?? "")")
    }
}
