//
//  StructuralPatternViewController.swift
//  iosTest
//
//  Created by 周诗玮 on 2024/10/23.
//

import UIKit

/// 结构型模式
class StructuralPatternViewController: UIViewController {
    
    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: - 1 适配器模式（Adapter Pattern）
        /// 继承
        let api = Adapter()
        api.newRequest()
        
        
        /// 依赖
        let adapter = DependencyAdapter()
        adapter.oldAPI = OldAPI()
        adapter.newRequest()
        
        
        // MARK: - 2 桥接模式（Bridge Pattern）
         // 创建具体的实现对象A
        let implementorA = ConcreteImplementorA()
        // 创建抽象部分对象，并将具体的实现对象A桥接进去
        let abstraction = Abstraction()
        abstraction.implementor = implementorA
        // 调用抽象部分的操作
        abstraction.doAction()

        // 创建具体的实现对象B
        let implementorB = ConcreteImplementorB()
        // 将具体的实现对象B桥接进抽象部分对象
        abstraction.implementor = implementorB
        // 调用抽象部分的操作
        abstraction.doAction()
        
        
        // MARK: - 3 组合模式(Composite Pattern)
        let root = Directory(name: "root")
        let documents = Directory(name: "Documents")
        let readme = File(name: "readme.txt")
        documents.add(readme)
        root.add(documents)
        let pictures = Directory(name: "Pictures")
        let photo1 = File(name: "photo1.jpg")
        let photo2 = File(name: "photo2.jpg")
        pictures.add(photo1)
        pictures.add(photo2)
        root.add(pictures)
        root.add(File(name: "notes.txt"))
        
        printFileSystem(root)
        
        
        // MARK: - 4 装饰器模式（Decorator Pattern）
        let rectangle = ShapeDecoratorFactory.decoratedShape(withType: "rectangle")
        rectangle?.draw()

        let circle = ShapeDecoratorFactory.decoratedShape(withType: "circle")
        circle?.draw()
        
        
        // MARK: - 5 外观模式（Facade Pattern）
        /// 第三方封装的网络请求就是外观模式
        
        
        // MARK: - 6 享元模式（Flyweight Pattern）
        /// 举例 tableView的cell 就是享元模式
      
        
        // MARK: - 7 代理模式（Proxy Pattern）
        let downloader = DownloaderProxy()
        downloader.downloadFile("http://example.com/file.txt")
    }
    
}


// MARK: - 1 适配器模式（Adapter Pattern）
/// 继承
// 旧接口
class OldAPI: NSObject {
    func legacyRequest() {
        print("执行旧接口的请求")
    }
}

// 目标接口
protocol NewAPI: NSObjectProtocol {
    func newRequest()
}

// 适配器子类，继承自旧接口类并实现目标接口
class Adapter: OldAPI, NewAPI {
    func newRequest() {
        legacyRequest() // 调用旧接口的方法
        print("执行适配后的新请求")
    }
}

/// 依赖
// 适配器类，通过依赖旧接口类来实现适配
class DependencyAdapter: NSObject, NewAPI {
    var oldAPI: OldAPI?

    func newRequest() {
        oldAPI?.legacyRequest() // 调用旧接口的方法
        print("执行适配后的新请求")
    }
}


// MARK: - 2 桥接模式（Bridge Pattern）
// 实现部分的接口
protocol Implementor: NSObjectProtocol {
    func doSomething()
}

// 实现部分的具体实现类A
class ConcreteImplementorA: NSObject, Implementor {
    func doSomething() {
        print("Concrete Implementor A is doing something.")
    }
}

// 实现部分的具体实现类B
class ConcreteImplementorB: NSObject, Implementor {
    func doSomething() {
        print("Concrete Implementor B is doing something.")
    }
}

// 抽象部分
class Abstraction {
    var implementor: Implementor?

    func doAction() {
        implementor?.doSomething()
    }
}


// MARK: - 3 组合模式(Composite Pattern)
///
class FileSystemComponent: NSObject {
    
    var name: String?
    
    init(name: String?) {
        super.init()
        self.name = name
    }
    
    func add(_ component: FileSystemComponent?) {
        // 默认实现为空，只有组合节点需要实现该方法
    }
    
    func remove(_ component: FileSystemComponent?) {
        // 默认实现为空，只有组合节点需要实现该方法
    }
    
    func getChildren() -> [FileSystemComponent]? {
        // 默认实现为空，只有组合节点需要实现该方法
        return nil
    }
}

class File: FileSystemComponent {
    
}

class Directory: FileSystemComponent {
    private var children: [FileSystemComponent]?
    
    override init(name: String?) {
        super.init(name: name)
        children = []
    }
    
    override func add(_ component: FileSystemComponent?) {
        if let component {
            children?.append(component)
        }
    }
    
    override func remove(_ component: FileSystemComponent?) {
        children?.removeAll { $0 as AnyObject === component as AnyObject }
    }
    
    override func getChildren() -> [FileSystemComponent]? {
        return children
    }
}

func printFileSystem(_ component: FileSystemComponent?) {
    if let name = component?.name {
        print("\(name)")
    }
    if component is Directory {
        let directory = component as? Directory
        let children = directory?.getChildren()
        for child in children ?? [] {
            printFileSystem(child)
        }
    }
}


// MARK: - 4 装饰器模式（Decorator Pattern）
///
protocol Shape: NSObjectProtocol {
    func draw()
}

///
class Rectangle4: NSObject, Shape {
    func draw() {
        print("绘制矩形")
    }
}

///
class Circle4: NSObject, Shape {
    func draw() {
        print("绘制圆形")
    }
}

///
class ColorDecorator: NSObject, Shape {
    var shape: (any Shape)?

    init(shape: (any Shape)?) {
        super.init()
        self.shape = shape
    }

    func draw() {
        shape?.draw()
        print("添加颜色")
    }
}

///
class BorderDecorator: NSObject, Shape {
    var shape: (any Shape)?

    init(shape: (any Shape)?) {
        super.init()
        self.shape = shape
    }

    func draw() {
        shape?.draw()
        print("添加边框")
    }
}

///
class ShapeDecoratorFactory: NSObject {
    class func decoratedShape(withType type: String?) -> Shape? {
        
        var shape: Shape?
        
        if type == "rectangle" {
            shape = Rectangle4()
        } else if type == "circle" {
            shape = Circle4()
        }
        
        // 创建装饰器对象，并返回装饰后的形状
        shape = ColorDecorator(shape: shape)
        shape = BorderDecorator(shape: shape)
        return shape
    }
}


// MARK: - 5 外观模式（Facade Pattern）
/// 第三方封装的网络请求就是外观模式


// MARK: - 6 享元模式（Flyweight Pattern）
/// 举例 tableView的cell 就是享元模式


// MARK: - 7 代理模式（Proxy Pattern）
///
// Downloader
protocol Downloader: NSObjectProtocol {
    func downloadFile(_ url: String?)
}

// RealDownloader
class RealDownloader: NSObject, Downloader {
    func downloadFile(_ url: String?) {
        print("RealDownloader: Downloading file from \(url ?? "")")
    }
}

// DownloaderProxy
class DownloaderProxy: NSObject, Downloader {
    var realDownloader: RealDownloader?

    func downloadFile(_ url: String?) {
        print("DownloaderProxy: Preparing to download file from \(url ?? "")")

        if realDownloader == nil {
            realDownloader = RealDownloader()
        }

        realDownloader?.downloadFile(url)

        print("DownloaderProxy: File download complete")
    }
}
