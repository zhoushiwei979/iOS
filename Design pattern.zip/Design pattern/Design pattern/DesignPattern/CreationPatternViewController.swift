//
//  CreationPatternViewController.swift
//  iosTest
//
//  Created by 周诗玮 on 2024/10/22.
//

import UIKit

/// 创建性模式
class CreationPatternViewController: UIViewController {
    
    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: -  1 简单工厂模式（Simple Factory Pattern）
        let dog = AnimalFactory().createAnimalWithType(type: .dog)
        dog.speak()
        
        let cat = AnimalFactory().createAnimalWithType(type: .cat)
        cat.speak()
        
        
        // MARK: -  2 工厂方法模式(Factory Method Pattern)
        let factory = CircleFactory()
        let shape = factory.createShape()
        shape.draw()
        
        
        // MARK: -  3 抽象工厂模式(Abstract Factory Pattern)
        let factoryiOS = iOSFactory()
        let factoryAndroid = AndroidFactory()
        // 使用iOS风格的按钮和标签
        let _ = factoryiOS.createButton()
        let _ = factoryiOS.createLabel()
        // 使用Android风格的按钮和标签
        let _ = factoryAndroid.createButton()
        let _ = factoryAndroid.createLabel()
        
        
        // MARK: - 4 单例模式(Singleton Pattern)
    
        
        // MARK: - 5 原形模式(Prototype Pattern)
        // 创建原型对象
        let prototypeView = MyView()
        prototypeView.titleLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        prototypeView.button = UIButton(frame: CGRect(x: 0, y: 60, width: 100, height: 50))
        // 复制原型对象，创建新的对象
        let newView = prototypeView.copy()
        newView.titleLabel?.text = "Hello word"
        newView.button?.setTitle("Click", for: .normal)
        
        
        // MARK: - 6 建造者模式(Builder Pattern)
        let builder = ResumeBuilder()
        let director = ResumeDirector(builder: builder)
        let str = director.construct() ?? ""
        print("builderPattern:\(str)")
    }
    
}


// MARK: - 1 简单工厂模式（Simple Factory Pattern）
class Animals {
    //
    let name: String = ""
    //
    func speak() {
        print("I am an animal")
    }
}

class Dogs: Animals {
    //
    override func speak() {
        print("I am a dog")
    }
}

class Cats: Animals {
    //
    override func speak() {
        print("I am a cat")
    }
}

class AnimalFactory {
    //
    enum AnimalType {
        case dog
        case cat
    }
    //
    func createAnimalWithType(type: AnimalType) -> Animals {
        switch type {
        case .dog:
            Dogs()
        case .cat:
            Cats()
        }
    }
}


// MARK: - 2 工厂方法模式(Factory Method Pattern)
// 产品接口
protocol ShapeProtocol: NSObjectProtocol {
    func draw()
}

// 具体产品A
class Circle: NSObject, ShapeProtocol {
    func draw() {
        print("绘制圆形")
    }
}

// 具体产品B
class Rectangle: NSObject, ShapeProtocol {
    func draw() {
        print("绘制矩形")
    }
}

// 抽象工厂
protocol ShapeFactoryProtocol: NSObjectProtocol {
    func createShape() -> ShapeProtocol
}

// 具体工厂A
class CircleFactory: NSObject, ShapeFactoryProtocol {
    func createShape() -> ShapeProtocol {
        return Circle()
    }
}

// 具体工厂B
class RectangleFactory: NSObject, ShapeFactoryProtocol {
    func createShape() -> ShapeProtocol {
        return Rectangle()
    }
}


// MARK: - 3 抽象工厂模式(Abstract Factory Pattern)
///
protocol AbstractFactoryProtocol: NSObjectProtocol {
    func createButton() -> UIButton
    func createLabel() -> UILabel
}

/// iOS风格的具体工厂类
class iOSFactory: NSObject, AbstractFactoryProtocol {
    ///
    func createButton() -> UIButton {
        return UIButton(type: .system)
    }
    ///
    func createLabel() -> UILabel {
        return UILabel()
    }
}

/// Android风格的具体工厂类
class AndroidFactory: NSObject, AbstractFactoryProtocol {
    ///
    func createButton() -> UIButton {
        return UIButton(type: .roundedRect)
    }
    ///
    func createLabel() -> UILabel {
        return UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
    }
}


// MARK: - 4 单例模式(Singleton Pattern)
///
class Manager {
    static let shared = Manager()
}


// MARK: - 5 原形模式(Prototype Pattern)
///
class MyView: Copyable {
    
    ///
    var titleLabel: UILabel?
    ///
    var button: UIButton?
    
    /// 实现复制方法
    required init(instance: MyView) {
        self.titleLabel = instance.titleLabel
        self.button = instance.button
    }
    
    ///
    init() {
        
    }
    
    ///
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

///
protocol Copyable {
    init(instance: Self)
}

///
extension Copyable {
    func copy() -> Self {
        return Self.init(instance: self)
    }
}


// MARK: - 6 建造者模式(Builder Pattern)
/// Person 类
class Person {
    var name: String = ""
    var email: String = ""
    var phone: String = ""
    var address: String = ""
}

/// Education 类
class Education {
    var degree: String = ""
    var school: String = ""
    var date: String = ""
}

/// WorkExperience 类
class WorkExperience {
    var company: String = ""
    var position: String = ""
    var date: String = ""
}

/// 建造者接口
protocol ResumeBuilderProtocol: NSObjectProtocol {
    func buildBasicInfo(withName name: String, email: String, phone: String, address: String)
    func buildEducation(withDegree degree: String, school: String, date: String)
    func buildWorkExperience(withCompany company: String, position: String, date: String)
    func getResult() -> String
}

/// 简历建造者类
class ResumeBuilder: NSObject, ResumeBuilderProtocol {
    
    var person: Person?
    var education: Education?
    var workExperience: WorkExperience?
    
    func buildBasicInfo(withName name: String, email: String, phone: String, address: String) {
        person = Person()
        person?.name = name
        person?.email = email
        person?.phone = phone
        person?.address = address
    }

    func buildEducation(withDegree degree: String, school: String, date: String) {
        education = Education()
        education?.degree = degree
        education?.school = school
        education?.date = date
    }
    
    func buildWorkExperience(withCompany company: String, position: String, date: String) {
        workExperience = WorkExperience()
        workExperience?.company = company
        workExperience?.position = position
        workExperience?.date = date
    }
    
    func getResult() -> String {
        var result = ""
        if let person = person {
            result += "Name: \(person.name)\n"
            result += "Email: \(person.email)\n"
            result += "Phone: \(person.phone)\n"
            result += "Address: \(person.address)\n"
            result += "\n"
        }
        if let education = education {
            result += "Education:\n"
            result += "Degree: \(education.degree)\n"
            result += "School: \(education.school)\n"
            result += "Date: \(education.date)\n"
            result += "\n"
        }
        if let workExperience = workExperience {
            result += "Work Experience:\n"
            result += "Company: \(workExperience.company)\n"
            result += "Position: \(workExperience.position)\n"
            result += "Date: \(workExperience.date)\n"
        }
        return result
    }
}

// 简历指导者类
class ResumeDirector {
    var builder: ResumeBuilderProtocol?
    
    init(builder: ResumeBuilderProtocol? = nil) {
        self.builder = builder
    }
    
    func construct() -> String? {
        builder?.buildBasicInfo(
            withName: "zhoushiwei",
            email: "zhoushiwei@163.com",
            phone: "1234567890",
            address: "test.")
        builder?.buildEducation(
            withDegree: "zhoushiwei",
            school: "zhoushiwei",
            date: "2001-2002")
        builder?.buildWorkExperience(
            withCompany: "123",
            position: "456",
            date: "2003-2004")
        return builder?.getResult()
    }
}
